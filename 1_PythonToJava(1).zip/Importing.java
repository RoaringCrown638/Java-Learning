import java.lang.Math;

// Importing.java
// An example of Importing in java

public class Importing {
   public static void main( String args[] ) {

		System.out.println( "Math.round(6.73) = " + Math.round(6.73) );
		System.out.println( "Math.sqrt(5) = " + Math.sqrt(5) );
		
   }
}
