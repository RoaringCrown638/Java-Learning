public class Comments {
   
   /*
		This is a multi-line comment.
		This is a multi-line comment.
   */
   public static void main( String args[] ) {
      System.out.println( "Print Something!" ); //This is a end of line comment
   }
}