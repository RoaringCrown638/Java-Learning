public class CastTest {
	public static void main( String args[] ) {
		int i = 150;
        
        // Cast i to a float...
        System.out.println( (float) i );
        
        // Cast i to a double...
        System.out.println( (double) i );
        
        // Cast i to a long...
        System.out.println( (long) i );

        // Write code here to try casting i to other primitive types:
        //   short, byte, char, and boolean
	}
}
